JumpDrive Secure Icon
=====================

Downloaded from http://www.benjaminoakes.com/

I made this back during the relatively brief period in which I used Windows XP.  I've since abandoned that platform and mostly use Mac OS X (and sometimes Linux).  I might convert this for OS X if there's enough demand.  Please send me an email.

Copyright 2004 Benjamin Oakes <hello@benjaminoakes.com>
